print(2*3)
