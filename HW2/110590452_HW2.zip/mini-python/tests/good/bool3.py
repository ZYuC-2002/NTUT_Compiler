print(1>2 and len(1))
