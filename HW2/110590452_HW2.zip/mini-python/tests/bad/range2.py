x = list(range(7))
print(x[7])

